// Exp 23: Study of ARM Processor (LPC2148)
// Theory experiment – No executable code required.